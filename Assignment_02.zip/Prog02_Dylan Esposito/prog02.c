#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//Function used to read files and check to see if the target is located within
int readData(char * target, char * file){

		//Make a call to the file class and create a pointer titled fp.
		FILE * fp;
		//Set fp to fopen whatever file has been passed through the 
		fp = fopen(file, "r");

		/*
		Here are the variables needed to read through the file.
		Numoccur will mark the number of occurences that we find a match for our target.
		Char temp is temporary char that we use to temporarily store lines from the text file so 
		we can perform our comparisons.
		Finally target2 is set equal to the value of the target parameter. This is done to 
		avoid potentially errors when reading through files.
		*/
		int numOccur = 0;
		char temp[1000];
		char * target2 = target;

		/*
			Here we go through the entire list and check to see if the files
			The !feof tactic was something I learned from a C programming tutorial awhile back.
			it is usefull when reading a file.
		*/
		while(!feof(fp)){
			fgets(temp,1000, fp);
			//Check done here to see if the line in temp contains any strings 
			//similair to the target, if so we increment numOccur by one.
			if(strstr(temp, target2)!= NULL)
			{
				numOccur = numOccur + 1;
			}
		}
		
		/*
		Here we close the file and return the number of occurences.
		*/
		fclose(fp);
		return numOccur;
}

int main (int argc, char * argv[]){

	//Start off by creatring a variable x that is set to zero.	
	int x = 0;

	/*
	The method I took for approaching this assignment was to initially start with a for loop that
	begins at the third element in the command line. The assumption here is that the text files the user
	wants to go over are 
	*/
	for(int i = 3; i < argc; i++)
	{
		//x is set equal to the returned from the readData function plus itself
		x = x + readData(argv[1], argv[i]);		
	}

	printf("%d", x);
	return x;

}
