// Name: Dylan Esposito
//  main.c
//  Final Project CSC412
//
//  Created by Jean-Yves Hervé on 2017-05-01.
//  Copyright © 2017 Jean-Yves Hervé. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <dirent.h>
#include <pthread.h>
//
#include "gl_frontEnd.h"
#include "fileIO_TGA.h"

#define THREADED_VERSION	0

//==================================================================================
//	Function prototypes
//==================================================================================
void displayImagePane(void);
void displayStatePane(void);

int max(int r, int g, int b);

void myKeyboard(unsigned char c, int x, int y);
void initializeApplication(char* fileName);
ImageStruct readImage(char* filePath);
void* threadFunc(void* arg);
void* threadFunc2(void* arg);

//==================================================================================
//	Application-level global variables
//==================================================================================

//	Don't touch. These are defined in the front end source code
extern const int IMAGE_PANE, STATE_PANE;
extern int	gMainWindow, gSubwindow[2];
extern const int IMAGE_PANE_WIDTH, IMAGE_PANE_HEIGHT;

//	Don't rename any of these variables/constants
//--------------------------------------------------
int numLiveThreads = 0;		//	the number of live focusing threads

//	An array of C-string where you can store things you want displayed in the spate pane
//	that you want the state pane to display (for debugging purposes?)
//	Dont change the dimensions as this may break the front end
//	I preallocate the max number of messages at the max message
//	length.  This goes against some of my own principles about
//	good programming practice, but I do that so that you can
//	change the number of messages and their content "on the fly,"
//	at any point during the execution of your program, whithout
//	having to worry about allocation and resizing.
const int MAX_NUM_MESSAGES = 8;
const int MAX_LENGTH_MESSAGE = 32;
char** message;
int numMessages;
time_t launchTime;

//	This is the image that you should be writing into.  In this
//	handout, I simply read one of the input images into it.
//	You should not rename this variable unless you plan to mess
//	with the display code.
ImageStruct imageOut;
ImageStruct* stack;
ImageStruct bestImage;
ImageStruct bestImage2;
ImageStruct bestImage3;

int stackSize;
float scaleX, scaleY;

typedef struct ThreadInfo {
	pthread_t threadId;
	int index;
	int startRow, endRow, startCol, endCol;
} ThreadInfo;

ThreadInfo* threadArray;

int nbVertSlabs = 4;
int nbHorizSlabs = 5;
int whs = 5;
int lhs = 4;

//------------------------------------------------------------------
//	The variables defined here are for you to modify and add to
//------------------------------------------------------------------
#define IN_PATH		"./DataSets/Series02/"
#define OUT_PATH	"./Output/"
#define VERSION 		2

#define folderPath "./home/Documents/Handout/Series01"
#define hardCodedInput "./_MG_6303.tga"
#define otherInput "./_MG_6304.tga"

//==================================================================================
//	These are the functions that tie the computation with the rendering.
//	Some parts are "don't touch."  Other parts need your intervention
//	to make sure that access to critical section is properly synchronized
//==================================================================================

//	I can't see any reason why you may need/want to change this
//	function
void displayImagePane(void)
{
	//==============================================
	//	This is OpenGL/glut magic.  Don't touch
	//==============================================
	glutSetWindow(gSubwindow[IMAGE_PANE]);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glPixelZoom(scaleX, scaleY);

	//--------------------------------------------------------
	//	stuff to replace or remove.
	//	Here I assign a random color to a few random pixels
	//--------------------------------------------------------
	/*
	for (int k=0; k<100; k++) {
		int i = random() % imageOut.nbRows;
		int j = random() % imageOut.nbCols;
		//	I make sure that my alpha channel is 255
		int newCol = (int)(random() % 0x100000000) | 0xFF000000;
		
		//destination
		int* dest = (int*) imageOut.raster;
		//set a certain index of dest to the newlCol
		dest[i*imageOut.nbCols + j] = newCol;
	}
	*/

	//==============================================
	//	This is OpenGL/glut magic.  Don't touch
	//==============================================
	glDrawPixels(imageOut.nbCols, imageOut.nbRows,
				  GL_RGBA,
				  GL_UNSIGNED_BYTE,
				  imageOut.raster);
	glutSwapBuffers();
	glutSetWindow(gMainWindow);
}

void displayStatePane(void)
{
	//==============================================
	//	This is OpenGL/glut magic.  Don't touch
	//==============================================
	glutSetWindow(gSubwindow[STATE_PANE]);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();


	//--------------------------------------------------------
	//	stuff to replace or remove.
	//--------------------------------------------------------
	//	Here I hard-code a few messages that I want to see displayed
	//	in my state pane.  The number of live focusing threads will
	//	always get displayed.  No need to pass a message about it.
	time_t currentTime = time(NULL);
	numMessages = 3;
	sprintf(message[0], "System time: %ld", currentTime);
	//sprintf(message[1], "Time since launch: %ld", currentTime-launchTime);
	sprintf(message[2], "It takes about ten seconds to load...happy holidays!");
	
	
	//---------------------------------------------------------
	//	This is the call that makes OpenGL render information
	//	about the state of the simulation.
	//	You may have to synchronize this call if you run into
	//	problems, but really the OpenGL display is a hack for
	//	you to get a peek into what's happening.
	//---------------------------------------------------------
	drawState(numMessages, message);

	//==============================================
	//	This is OpenGL/glut magic.  Don't touch
	//==============================================
	glutSwapBuffers();
	glutSetWindow(gMainWindow);
}

//	This callback function is called when a keyboard event occurs
//	You can change things here if you want to have keyboard input
//
void myKeyboard(unsigned char c, int x, int y)
{
	int ok = 0;
	
	switch (c)
	{
		//	'esc' to quit
		case 27:
			exit(0);
			break;

		default:
			ok = 1;
			break;
	}
	if (!ok)
	{
		//	do something?
	}
	
	//==============================================
	//	This is OpenGL/glut magic.  Don't touch
	//==============================================
	glutSetWindow(gMainWindow);
	glutPostRedisplay();
}

//------------------------------------------------------------------------
//	You shouldn't have to change anything in the main function.
//------------------------------------------------------------------------
int main(int argc, char** argv)
{
	//	Even though we extracted the relevant information from the argument
	//	list, I still need to pass argc and argv to the front-end init
	//	function because that function passes them to glutInit, the required call
	//	to the initialization of the glut library.
	initializeFrontEnd(argc, argv, displayImagePane, displayStatePane, myKeyboard);
	char* dataRootPath = argv[1];

	//	Now we can do application-level initialization
	initializeApplication(dataRootPath);
	//	Now we can do application-level initialization

	//==============================================
	//	This is OpenGL/glut magic.  Don't touch
	//==============================================
	//	Now we enter the main loop of the program and to a large extend
	//	"lose control" over its execution.  The callback functions that
	//	we set up earlier will be called when the corresponding event
	//	occurs
	glutMainLoop();
	
	//	Free allocated resource before leaving (not absolutely needed, but
	//	just nicer.  Also, if you crash there, you know something is wrong
	//	in your code.
	for (int k=0; k<MAX_NUM_MESSAGES; k++)
		free(message[k]);
	free(message);
	
	//	This will probably never be executed (the exit point will be in one of the
	//	call back functions).
	return 0;
	
	
}

//	If you have a modified/enhanced version of the image reading/writing
// 	code, then feel free to use it to replace the one included, but you
//	shouldn't *have* to change this.
ImageStruct readImage(char* filePath)
{
	int nbRows, nbCols;
	ImageFileType imgType;
	
	unsigned char* myData = readTGA(filePath, &nbRows, &nbCols, &imgType);
	
	ImageStruct img;
	if (myData != NULL)
	{
		img.raster = myData;
		img.nbCols = nbCols;
		img.nbRows = nbRows;
		if (imgType == kTGA_COLOR)
			//	all my color images are stored on 4 bytes:  RGBA
			img.bytesPerPixel = 4;
		else
			img.bytesPerPixel = 1;

		img.bytesPerRow = img.bytesPerPixel * nbCols;
	}
	else
	{
		printf("Reading of image file failed.\n");
		exit(-1);
	}

	return img;
}

//==================================================================================
//	This is a part that you have to edit and add to, for example to
//	load a complete stack of images and initialize the output image
//	(right now it is initialized simply by reading an image into it.
//==================================================================================


#define THREAD_VERSION	0

void initializeApplication(char* fileName)
{

	//	I preallocate the max number of messages at the max message
	//	length.  This goes against some of my own principles about
	//	good programming practice, but I do that so that you can
	//	change the number of messages and their content "on the fly,"
	//	at any point during the execution of your program, whithout
	//	having to worry about allocation and resizing.
	message = (char**) malloc(MAX_NUM_MESSAGES*sizeof(char*));
	for (int k=0; k<MAX_NUM_MESSAGES; k++)
		message[k] = (char*) malloc((MAX_LENGTH_MESSAGE+1)*sizeof(char));
	
	//printf("%s\n", "Directory opened");
	DIR* directory = opendir(fileName);
    	if (directory == NULL) {
		printf("data folder %s not found\n", fileName);
		return 1;
	}
	struct dirent* entry;
	int counter = 0;
	
	//First we count the number of entries
    	while ((entry = readdir(directory)) != NULL) {
		char* name = entry->d_name;
		//printf("%s\n", name);
		//printf(name);
		if (name[0] != '.') {
			counter++;
		}
   	 }
	//close directory
	closedir(directory);

	stackSize = counter+1;
	
	//Tried to read the filenames into a char pointer array but errors would result in a series of poorly compressed images that created a bad output.
	char* path[15] = {"./Series02/_MG_6303.tga", "./Series02/_MG_6304.tga", "./Series02/_MG_6305.tga","./Series02/_MG_6306.tga","./Series02/_MG_6307.tga","./Series02/_MG_6307.tga","./Series02/_MG_6308.tga","./Series02/_MG_6309.tga","./Series02/_MG_6310.tga","./Series02/_MG_6311.tga","./Series02/_MG_6312.tga","./Series02/_MG_6313.tga","./Series02/_MG_6314.tga","./Series02/_MG_6315.tga","./Series02/_MG_6316.tga"};
	
	//Create a stack that will contain the images within the path
	stack = (ImageStruct*) calloc(stackSize, sizeof(ImageStruct));
	for (int k=0; k<stackSize; k++) {
	
		//Print which files have been read
		printf("k=%d, reading image file %s\n", k, path[k]);
		//Assign the files to the stack after sending them to the readImage funct
		stack[k] = readImage(path[k]);
	}
	
	//Here we sent number of rows,cols,bytesPerRow, bytesPerPixel for the output image
	//We are assuming the images are all the same size
	imageOut.nbRows = stack[0].nbRows;	
	imageOut.nbCols = stack[0].nbCols;	
	imageOut.bytesPerRow = stack[0].bytesPerRow;
	imageOut.bytesPerPixel = stack[0].bytesPerPixel;
	imageOut.raster = (unsigned char*) calloc(imageOut.nbRows*imageOut.bytesPerRow, sizeof(unsigned char));


	scaleX = (1.f*IMAGE_PANE_WIDTH)/imageOut.nbCols;
	scaleY = (1.f*IMAGE_PANE_HEIGHT)/imageOut.nbRows;
	launchTime = time(NULL);

	//Create ints that will determine the size of windows
	int slabHeight = imageOut.nbRows / nbHorizSlabs;
	int slabWidth = imageOut.nbCols / nbVertSlabs;
	
	//Create threadArray that will send threads to the windows to go through
	threadArray = (ThreadInfo*) calloc(nbHorizSlabs*nbVertSlabs, sizeof(ThreadInfo));
	int index = 0;
	int limit = nbHorizSlabs * nbVertSlabs;

	//Define the number of threads to store
	pthread_t threadID[limit];

	//define regions that will appear over your image
	for (int h = 0; h < nbHorizSlabs; h++) {
		for (int v=0; v < nbVertSlabs; v++, index++) {
			//initialize threadArray struct
			//Set index equal to inddex
			//Correct startRow and endRow values through each iteration of loop
			threadArray[index].index = index;
			threadArray[index].startRow = h*slabHeight;
			threadArray[index].endRow = (h+1)*slabHeight - 1;
			
			//managing rows and preventing 
			if (threadArray[index].endRow >= imageOut.nbRows)
				threadArray[index].endRow = imageOut.nbRows-1;
		    
		    	//managing columns
			threadArray[index].startCol = v*slabWidth;
			threadArray[index].endCol = (v+1)*slabWidth - 1;
			if (threadArray[index].endCol >= imageOut.nbCols)
				threadArray[index].endCol = imageOut.nbCols-1;
		
//NOTE TO ACTIVATE: Start and inlcude folder as value after ./focus 
			//Pthread creation that sends array of threads to threadFunc, or version 1 in other words
			pthread_create(&(threadArray[index].threadId), NULL, threadFunc, threadArray + index);			
			
			//Uncomment below for version two
			//pthread_create(&(threadArray[index].threadId), NULL, threadFunc2, threadArray + index);

			
			//If thread creation does not work, use these for test cases
			//threadFunc(threadArray + index);
			//threadFunc2(threadArray + index);
			//displayImagePane();
				
		}
	}

	//Wait until all the threads have completed
	for(int y = 0; y < limit; y++){
		void* retVal;
		pthread_join(threadArray[index].threadId, &retVal);
	}
	
}	

void* threadFunc(void* arg) {

	ThreadInfo* info = (ThreadInfo*)(arg);
 	
	//create values that will point to colors within in pixel
	int greyValue, greyValue2, greyValue3;

	//Begin at the start of the window and end at the final row within the window
	for (int i = info->startRow; i<= info->endRow; i++) {
		//for each col in the region
		for (int j = info->startCol; j <= info->endCol; j++) {
			//Create varaibles that measure focus, max and min values within each of the colors for the image	
			int focus = 0;
			int focus2 = 0;
			int focus3 = 0;
			int max = 0;
			int max2 = 0;
			int max3 = 0;
			int min = 254;
			int min2 = 254;
			int min3 = 254;
			for(int s = 0; s < stackSize; s++){
				for (int k=-whs; k<= whs; k++) {
					for (int l=-lhs; l<=lhs; l++) {
						//greyValue = (stack[s].raster[(i+k)*stack[s].bytesPerRow + 4*(j+l) + 0]); //Issue when going through these values at i+k and j + l
						int q = i + k;
						int t = j + l;
						int tempFocus = 0;

						//Checks done to see if q or t results in a pixel that could be out of bounds
						if (q > info->endRow)
							q = info->endRow;
						else if(q < info->startRow)
							q = info->startRow;
						
						if(t > info->endCol)
							t = info->endCol;
						else if(t < info->startCol)
							t = info->startCol;
						
						//Set the greyvalue equal to the first color, then go through to check if it is larger than the max or smaller than the min.
						greyValue = (stack[s].raster[q*stack[s].bytesPerRow + 4*t + 0]);
						if(greyValue > max)
							max = greyValue; 	
						if(greyValue < min){
							min = greyValue;
						}	
						
						//Set tempFocus equal to the the result of max - min. If larger than the max we currently hold then we best BestImage equal to 
						//image on the stack
						tempFocus = max - min;
						if(tempFocus > focus){
								focus = tempFocus;
								bestImage = stack[s];
						}

						//Set the greyvalue2 equal to the first color, then go through to check if it is larger than the max or smaller than the min.
						greyValue2 = (stack[s].raster[q*stack[s].bytesPerRow + 4*t + 1]);
						if(greyValue2 > max2)
							max2 = greyValue2; 	
						if(greyValue2 < min2){
							min2 = greyValue2;
						}	

						//Set tempFocus equal to the the result of max - min. If larger than the max we currently hold then we best BestImage equal to 
						//image on the stack	
						tempFocus = max2 - min2;
						if(tempFocus > focus2){
								focus2 = tempFocus;
								bestImage2 = stack[s];
						}
					
						//Set the greyvalue2 equal to the first color, then go through to check if it is larger than the max or smaller than the min.
						greyValue3 = (stack[s].raster[q*stack[s].bytesPerRow + 4*t + 2]);
						if(greyValue3 > max3)
							max3 = greyValue3; 	
						if(greyValue3 < min3){
							min3 = greyValue3;
						}

						//Set tempFocus equal to the the result of max - min. If larger than the max we currently hold then we best BestImage equal to 
						//image on the stack			
						tempFocus = max - min;
						if(tempFocus > focus3){
								focus3 = tempFocus;
								bestImage3 = stack[s];
						}
					 	//imageOut.raster[i*stack[0].bytesPerRow + 4*j] = bestScore-minScore;
					}//end l
				}//end k 

				//Assign the pixels of the ImageOut to the values inside of the bestImages
				imageOut.raster[i*imageOut.bytesPerRow + 4*j + 0] = bestImage.raster[i*bestImage.bytesPerRow + 4*j + 0];
				imageOut.raster[i*imageOut.bytesPerRow + 4*j + 1] = bestImage.raster[i*bestImage2.bytesPerRow + 4*j + 1];
				imageOut.raster[i*imageOut.bytesPerRow + 4*j + 2] = bestImage.raster[i*bestImage3.bytesPerRow + 4*j + 2];
			}//end s
		}//end j
		
	}//end i
					
	scaleX = (1.f*IMAGE_PANE_WIDTH)/stack[0].nbCols;
	scaleY = (1.f*IMAGE_PANE_HEIGHT)/stack[0].nbRows;
	launchTime = time(NULL);
	
	//free(info);
	return NULL;
	
}

void* threadFunc2(void* arg){
	/*

	while still going do 
		select a random pixel location;
		form a not-so-small rectangular window centered at the pixel;
		for each image of the focus stack do
			compute the focus measure over the window;
		end
		combine the colors of the most in-focus window of the stack with that in the output image
			The “color combination” of the algorithm is very simple:
		for each pixel in the most in focus window do
			if pixel value at that location in the output image is 0 (0xFF000000) then
				replace the value at that location by that in the most in focus window;
			else
			for each color channel, r, g, b, of the pixel do
				the new color value is 0.5 * most in focus value + 0.5 * old value in output image;
			end
		end
	end

	*/

	ThreadInfo* info = (ThreadInfo*)(arg);
	int counter = 0;
	int greyValue;
	
	while(counter <= 20000)
	{
		//Assign x and z random pixel locations.
		//X represents row, z represents column
		int x = random() % 1080;
		int z = random() % 1080;

		int* pixel = (int*)imageOut.raster + x*imageOut.nbCols + z;
		//value needs to start at the random pixel location, so maybe recover the location of the pixel
		//for each image in the stack
		int focus = 0;
		int max = 0;
		int min = 254;

		//for each image in the stack
		for(int s = 0; s < stackSize; s++){
			for (int k=-whs; k<= whs; k++) {
				for (int l=-lhs; l<=lhs; l++) {
					
					int q = x + k;
					int t = z + l;
					int tempFocus = 0;
					if (q < 0)
						q = 0;
					if(t < 0)
						t = 0;

					greyValue = ((stack[s].raster[q*stack[s].bytesPerRow + 4*t + 0]) + (stack[s].raster[q*stack[s].bytesPerRow + 4*t + 1]) + (stack[s].raster[q*stack[s].bytesPerRow + 4*t + 2]))/3;
			
					if(greyValue > max)
						max = greyValue; 	
					if(greyValue < min){
						min = greyValue;
					}		
					tempFocus = max - min;
					if(tempFocus >= 0){
						if(tempFocus > focus){
							focus = tempFocus;
							bestImage = stack[s];
						}
					}
				}//end l
			}//end k 
		}//end s
		
		//for each pixel in the most in focus window do
		for(int row = -whs; row <=whs; row++){
			for(int col = -lhs; col <=lhs; col++){
				int val = x + row;
				int val2 = z + lhs;
				
				if(bestImage.raster[x*bestImage.bytesPerRow + 4*z == NULL]){
					val = val + 5;
					val2 = val2 + 5;
				}

				//otherwise for each color channel, r, g, b, of the pixel do
				//the new color value is 0.5 * most in focus value + 0.5 * old value in output image;
				imageOut.raster[val*imageOut.bytesPerRow + 4*val2 + 0] = (0.5*focus) + (0.5*bestImage.raster[x*bestImage.bytesPerRow + 4*z + 0]);
				imageOut.raster[val*imageOut.bytesPerRow + 4*val2 + 1] = (0.5*focus) + (0.5*bestImage.raster[x*bestImage.bytesPerRow + 4*z + 1]);
				imageOut.raster[val*imageOut.bytesPerRow + 4*val2 + 2] = (0.5*focus) + (0.5*bestImage.raster[x*bestImage.bytesPerRow + 4*z + 2]);
			}
		}
			
		counter++;
		
	}

	//free(info);

	return NULL;
	
}
