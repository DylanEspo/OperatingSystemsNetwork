//=========================================================================
//	This code comes from the page "Non-blocking I/O with pipes in C"
//	by Kadam Patel on GeeksForGeeks
//	http://www.geeksforgeeks.org/non-blocking-io-with-pipes-in-c/
//
//
//	jyh 2017-10-13
//=========================================================================

// C program to illustrate
// non I/O blocking calls
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h> 	// library for fcntl function

//jyh 2017
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>	//	for exit system call
#include <errno.h>	//	defines some error handling constants and errno global
void parent_read(int p[]);
void distributorProc(int parentPipe[], int indexVal, int rangeSize);
void childProc(int parentPipe[]);
int countFiles(char * buff);

#define out_file "./assign3New/myFile.txt"
#define OUTPUT_ROOT_PATH "./Output/"
#define MSGSIZE 200

//jyh 2017
//int main()
int main(int argc, char* argv[])
{
	//Initalize two-way pipe that you can read and write into
	int d[2];

	// error checking for pipe
    	if (pipe(d) < 0)
        	exit(1);
	
    	// error checking for fcntl
    	if (fcntl(d[0], F_SETFL, O_NONBLOCK) < 0)
        	exit(2);
	
    	//Determine the number of files in directory
    	int j = countFiles(argv[1]);
    	//Convert max index given by script into a integer
	int max = *argv[2];
    	//Calculating the average number of files each process should take.
    	int numFiles = j/max;
	
    	/*
	Need to split the files into arrays or arrays of arrays that can easily be gathered
    	when giving the structures holding the arrays we should also pass the number per process
	*/
	
    	DIR *dp;
	//Create struct that allows us to output the file destination and store it into an array.
	struct dirent *ep; 
	//Opens the directory given to us by the csript
	dp = opendir (argv[1]);

	//Create two-dimensional array that can fit up to the number of values present in the dataset.  
	char buff[20][256];
	
    	//Value that helps us increment through the array.
    	int i = 0;
    	
	//Continuelly search through the directory as long as it is not empty.
    	if(dp!= NULL){
		//Loop that reads through the directory and allows us to store the titles of the files 
		//into the array.
		while(ep = readdir(dp)){
			//Here we combine the location of the directory with a dash and the name of the text file 
			//so we can call it later on.
			strcpy(buff[i], argv[1]);
			strcat(buff[i], "/");
			strcat(buff[i],ep->d_name);
			i++;
		}
    	}
	

	//Here we write all the files into the pipe
	//While it clearly limits the capabilities of this program,
	//it avoids the pitfals that come with trying to divide files via 
	for(int q = 0; q < j; q++)
	{	
		//Writing from buff[q] into the pipe. MSGSIZE is high since the length of files 
		//can vary depending on how deep they are in their directory.
		write(d[1], buff[q], MSGSIZE);
		
		//printf("%s\n", buff[q]);
		
	}

	//need to figure out how to let the fork wait for other messages to be sent in and register them
	//need a check to see if there are messages designated for a particular index
	int pid;
	max = max - 48;
	//printf("%d\n", max);
    	for(int i = 0; i < max; i++){
		//Fork here
		pid = fork();
		printf("%d\n", i);
    		
		//Error check performed to ensure that the we do not return a value lower than zero.
		if(pid < 0){
			exit(3);
		}
		//Means we are in a child process
        	else if(pid == 0){
			//Here we call the distributor process that goes through files and checks the indexes.
			distributorProc(d, i, numFiles);
			
			break;

		}
 		else{
			
			break;			

		}
    	}
	
   	return 0;
}


void distributorProc(int parentPipe[], int indexVal, int rangeSize){
	
	//Create fp to read through 
	FILE * fp;
	FILE * fp2;
	fp2 = fopen("outfile.txt", "a");
	//Create a pipe to allow us to send messages to the 
	//child process we create.
	int childPipe[2];
	// error checking for pipe
    	if (pipe(childPipe) < 0)
        	exit(1);
	
    	// error checking for fcntl
    	if (fcntl(childPipe[0], F_SETFL, O_NONBLOCK) < 0)
        	exit(2);
	
	//Create long nread to help us progress through the pipe.		
	long nread;
	for(int j = 0; j < rangeSize; j++)
	{
		//Create two arrays to temporarily store values in them
		//fileName stores the directory to the file
		//readingFile only pulls the index value located at the beginning of the file.
		char fileName[255];
		char readingFile[255];
		
		//Here we read the first value from the pipe and store it in the fileName array.
		nread = read(parentPipe[0], fileName, MSGSIZE);
		
		//Here we open up the file through the fileName and set the option to read only.
		fp = fopen(fileName, "r");
		//Retrieve the first value from the file which we consider the index. However the index is currently a char.
		fgets(readingFile, 2, fp);	
		//Convert index to integer	
		int x = *readingFile - '0';

		/*
		Wasn't intended but couldn't pass all the files correctly into the 
		Here we create an array that stores the str of the file and place it
		into the output file through fp2. Use fputs to place into the output file.
		*/
		char strToStore[255];
		fgets(strToStore, 255, fp);
   		fputs(strToStore, fp2);
                
		//Check if the value of x is equal to the given indexVal.
		if(x == indexVal){
			
			write(childPipe[1], fileName, MSGSIZE);
						
		}
		//otherwise create else statement and sends it back to parent for the parent to work on
		else{
			write(parentPipe[1], fileName, MSGSIZE);
			//printf("%s\n", "Rewriting backinto parentPipe");
		}
				
	}
	//Close fp, fp2 and the read for childPipe.
	close(childPipe[0]);
	int pid;

	//Here we create a child process to help organize files
	for(int m = 0; m < 1; m++){
		//Fork here
		pid = fork();
		// Error check to make
    		if(pid < 0)
        		exit(3);
 
    		// 0 for child process
    		else if(pid == 0){
			childProc(childPipe);
        		break;
		}
		// In parent, break here
    		else{
        		break;
		}
    	}
	

}

//Struggled to pass values through parentpipe into this function. 
//Break apart values, sort by line value here
//Need to read from pipe, sort values, store them in pipe and return them up to the grandparent
void childProc(int parentPipe[])
{	
	//test to see if correct values end up here
	close(parentPipe[1]);
	FILE * fp;
	//Create arrays here to help gather file names and go through them
        char breaker[1255];
	char strToStore[1255];
        char x;
        int y;
	long nread;
	for(int i = 0; i < 2; i++){
		//similar to distribution process, planned to check for line value 
		//and then arrange files into the array.
		nread = read(parentPipe[0], breaker, 255);
		fp = fopen(breaker, "r");
		fgets(strToStore, 255, fp);
                x = strToStore[2];
                y = x - '0';
        }	
    	exit(0);
}

//
int countFiles(char * buff){	
  	
	//Create DIR and pointer to dp.
  	DIR *dp;
	//Create structure that allows us to read the dp.
  	struct dirent *ep;
	//Open the directory with the given char pointer.     
  	dp = opendir (buff);
	//Create 
  	int i = 0;
  	if (dp != NULL)
  	{
		//Read through array and iterate by one each time we find a file.
    		while (ep = readdir (dp))
      			i++;

    		(void) closedir (dp);
  	}
  	else
    		perror ("Couldn't open the directory");
	//Reduce value by two since folders are coutned as two.
  	i = i - 2;
  	//printf("%d\n", i);
  	return i;
}
